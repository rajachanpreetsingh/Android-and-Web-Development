<?php
	session_start();
	include('config.php');
	
	$zipcode= $_POST['zipcode'];
	
	
	$query = "select zipcode.*, state.stateName, city.cityName from zipcode inner join state on zipcode.stateID = state.stateID
	inner join city on zipcode.cityID = city.cityID where zipCodeID='".$_POST['zipcode']."'";
	
	
	$result = mysql_query($query);
	
	if(mysql_num_rows($result) > 0)
	{
		$stateCityArray = [];
		while($fetch = mysql_fetch_array($result))
		{
			
			$_SESSION['cityname']=$fetch['cityName'];
			$_SESSION['statename']=$fetch['stateName'];
			$_SESSION['zipCode']=$fetch['zipCode'];
		   
		   
	      
		   
		   
		   
		   
			array_push($stateCityArray, [
			'City'   => $fetch['cityName'],
			'State' => $fetch['stateName']
			]);
			
		}
		$arrayJSON = json_encode($stateCityArray);
		
		echo $arrayJSON;
	}
	else{
		echo 'false';
	}
	
?>