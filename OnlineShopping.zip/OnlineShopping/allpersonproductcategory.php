<?php include('refrence.php');

?>

<body>

<div class="container">
    <div class="row">
    	<div class="col-md-12" style="margin-top:10px;">
     
          	<a href="personpcf2.php" class="btn btn-info" style="float:right;"><span class="glyphicon glyphicon-plus"></span> NEW ENTRY </a>
     
		</div>
      <div class="col-lg-12" style="margin-top:10px;">
      	<div class="well">
     		<h2 class="text-center"> ALL PERSON PRODUCT CATEGORIES </h2>
     	</div>
     </div>
       <div class="col-md-12">
       <table id="example" class="table table-striped table-hover" >
       <thead>
          <th>PRODUCT ID</th>
          <th>PRODUCT NAME</th>
          <th>STATUS</th>
           <th>MAIN CATEGORY ID</th>
          <th>MANAGE </th>
       </thead>
       <tbody>
       <?php 
       $sql="select person_product_category.subcategoryid, person_product_category.product_name, person_product_category.is_active,";
        $sql.=" person_category.category_name from person_product_category inner JOIN person_category ON";
         $sql.=" person_product_category.main_category_id = person_category.id where person_category.is_active=1";
        include('config.php');
       $res=mysql_query($sql);
       if (mysql_num_rows($res)>0){
       while($fetch=mysql_fetch_array($res)){
       ?>
       <tr>
        <td> <?php echo$fetch['subcategoryid']; ?></td>
       <td> <?php echo$fetch['product_name']; ?></td>
         <td class="response"> <?php echo$fetch['is_active']; ?></td>
         <td> <?php echo$fetch['category_name']; ?></td>
    <td> <a href="personpcf2.php?edit_id=<?php echo$fetch['subcategoryid']; ?>" class="btn btn-primary"> EDIT </a>
 
		<?php
			if($fetch['is_active']==1){
				?>
					<a href="#" statusVal="1" catid="<?php echo $fetch['subcategoryid'];?>" class="btn btn-danger btn-status">DISABLE</a>
				<?php
			}
			else{
				?>
					<a href="#" statusVal='0' catid="<?php echo $fetch['subcategoryid'];?>" class="btn btn-success btn-status">ENABLE</a>
				<?php
			}
		?>	
		</td>
	</tr>
	<?php
	}
			
		}
	?>
	
				
			</tbody>
		</table>
      
      
<script>
	$(document).ready(function(){
		$('#example').dataTable();
		
		$('body').on('click','.btn-status',function(e){
			e.preventDefault();
			var obj = $(this);
			$.ajax({
				type : 'post',
				dataType : 'json',
				url : 'changeproduct_status.php',
				data : {
					'statusVal' : obj.attr('statusVal'),
					'catId' : obj.attr('catid')
				},
				success : function(data){
			console.log(data);
					if(data.toString() == 'true'){
						
						if(obj.hasClass('btn-success')){
							obj.removeClass('btn-success');
							obj.addClass('btn-danger');
							obj.text('DISABLE');
							obj.closest('tr').find('.response').text('1');
							obj.attr('statusVal', '1');
						}
						else{
							obj.removeClass('btn-danger');
							obj.addClass('btn-success');
							obj.text('ENABLE');
							obj.closest('tr').find('.response').text('0');
							obj.attr('statusVal', '0');
						}
					}
					else{
						alert('something went wrong');
					}
				},
				error : function(data){
					console.log(data);
				}
			});
		});
		
	});
</script>
 </td>
 </tr>
  <?php
  

  ?>
       
      </tbody>
      
   
</body>