<?php
include ('refrence.php');

if(isset($_POST['update'])){
$name = ucwords(trim($_POST['productname']));
if(isset($_POST['status'])){
$status = true;
}
else{
$status = false;
}
$personcatid=$_POST['personcategory'];
$upSql = 'update person_product_category set product_name="'.$name.'",is_active="'.$status.'",main_category_id="'.$personcatid.'" where subcategoryid='.$_GET['edit_id'];


include('config.php');
$resupd = mysql_query($upSql);
if($resupd){
header('Location:allpersonproductcategory.php');
}
else{
echo mysql_error();
}
}
?>
<?php
if (isset($_GET['edit_id'])){
$sel="select person_product_category.product_name, person_product_category.is_active, person_category.id from person_product_category inner JOIN person_category ON  person_product_category.main_category_id = person_category.id where person_product_category.subcategoryid=".$_GET['edit_id'];
include('config.php');
$msr=mysql_query($sel);
$ms = mysql_fetch_array($msr);

}
include('refrence.php'); 
?>

<body>
<div class="container"> 
   <div class="row"> 
     <div class="col-lg-12">
     	<div class="well">
     		<h2 class="text-center"> Person product Category form </h2>
     	</div>
     </div>
          <?php
          if(isset($_GET['edit_id'])){
          	 $action = '';
          }
          else{
          	$action = 'action="insertpersonproductcategory.php"';	
          }
          
          ?>
     <div class="col-lg-12">
     <form class="form-horizontal" method="post" <?php echo $action; ?> >
  <div class="form-group">
    <label  class="col-sm-2 control-label">Product Name </label>
    <div class="col-sm-4">
    <?php
    							if(isset($ms['product_name'])){
    								$pdtname=$ms['product_name'];
    							}
    							else{
    								$pdtname='';
    							}
    						?>
      <input type="text" class="form-control" required name="productname" value="<?php echo $pdtname;?>">
    </div>
  </div>
  <div class="form-group">
    <label  class="col-sm-2 control-label">Person Category Name</label>
    <div class="col-sm-4">				
 						
     <select name="personcategory" class="form-control" required  >
     <option value="">SELECT</option>
     <?php
     
     $sql="select * from person_category where is_active=1 ";
     
     include('config.php');
     $res=mysql_query($sql);
     if(mysql_num_rows($res)>0)
     {
     while($fetch=mysql_fetch_array($res)){
     ?> 
     <?php
 		if(isset($ms['id'])){
 			$person_id=$ms['id'];
 			if($person_id == $fetch['id']){
 				$sel = 'selected';
 			}
 			else{
 				$sel = '';
 			}
 		}
 		  
 		?>
     <option value="<?php echo $fetch['id']?>" <?php if(isset($sel)) echo $sel;?>> <?php echo $fetch['category_name'] ?></option>
     <?php
     }
     }
     ?>
      </div>
     </select>
    </div>
  </div>
  <div class="form-group">
  <label class="col-sm-2 control-label">Status</label>
    <div class="col-sm-4">
      <div class="checkbox">
        <label>
        <?php
    	  					if(isset($ms['is_active']) && $ms['is_active']==1){
    							$check = 'checked';
    						}
    						else{
    							$check='';
    						}
    					?>
   					
          <input type="checkbox" name="status" <?php if(isset($check)) echo $check;?>> Is Active
        </label>
        
      </div>
      	
    </div>
    	
    				
  </div>
  <div class="form-group">
    <div class="col-sm-offset-2 col-sm-4">
    <?php
  								if(isset($_GET['edit_id'])){
									echo '<button type="submit" name="update" class="btn btn-warning">Update</button>&nbsp;
									<a href=allpersonproductcategory.php class="btn btn-default">Cancel</a>';
  								}
  								else{
  									echo '<button type="submit" name="create" class="btn btn-success">Submit</button>&nbsp;
  									<button type="reset" class="btn btn-default">Reset</button>';
  								}
  							?>
  							
    </div>
  </div>
</form>
     </div>
  </div>
</div>
     	

</body>