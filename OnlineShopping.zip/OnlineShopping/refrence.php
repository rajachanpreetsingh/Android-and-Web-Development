<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link href="styles/bootstrap.css" rel="stylesheet">
<link href="fonts/font-awesome.min.css" rel="stylesheet">
<link href="styles/prettyPhoto.css" rel="stylesheet">
<link href="styles/main.css" rel="stylesheet">
<link href="styles/animate.css" rel="stylesheet">
<link href="styles/jquery.dataTables.css" rel="stylesheet">
<link href="styles/bootstrap-datepicker.css" rel="stylesheet">

<script src="scripts/jquery-2.1.4.js"></script>
<script src="scripts/bootstrap.js"></script>
<script src="scripts/jquery.prettyPhoto.js"></script>
<script src="scripts/jquery.scrollUp.min.js"></script>
<script src="scripts/main.js"></script>
<script src="scripts/jquery.dataTables.js"></script>
<script src="scripts/bootstrap-datepicker.js"></script>

</head>
</html> 