<?php

if(isset($_POST['create'])){
$name = ucfirst(trim($_POST['productname']));
if(isset($_POST['status'])){
$status = true;
}
else{
$status = false;
}
$personcatid=$_POST['personcategory'];
$sql = "insert into person_product_category(product_name,is_active,main_category_id)";
$sql .= " values('".$name."','".$status."','".$personcatid."')";
include('config.php');
$res = mysql_query($sql);
if($res){

header('Location:allpersonproductcategory.php');
}
else{
echo mysql_error();
}
}
?>