
		
		<style type="text/css">
			.adminLink a{
			
			text-align: center;
			text-decoration: none;
			
			display: block;
			margin-bottom:15px;
			color: #31708f;
			padding: 4px 0 10px 0;
			transition: background-color 0.4s ease;
			}
			
			.adminLink a:hover{
			
			background-color: #31708f;
			color: white;
			border-radius: 6px;
			padding: 4px 0 10px 0;
			}
			
			.adminLink a span{
			font-weight: bold;
			}
			
			body  {
    background-image: url("back.jpg");
    background-color: #cccccc;
}

			#h {
   
   color:white;
}
			#h:hover {
   
   color:red;
}
 

			#c1 {
    background-image: url("done1.jpg");
    background-color: #cccccc;
}
		</style>
		
	<?php
	
     include('refrence.php');

	
	?>
	<body>
		<div class="container" >
			<div class="row">
				<div class="col-sm-12">
					<div class="page-header">
						<h2 id=h class="" > Admin Profile </h2>
					</div>
					<div class="panel panel-info">
						<div class="panel-heading">
							<h3 class="panel-title">Admin Links</h3>
						</div>
						<div class="panel-body" id=c1>
							<div class="col-md-12">
								<div class="col-md-6 adminLink">
									<a href="createmaincategoryform.php"><span class="glyphicon glyphicon-star">&nbsp;crate main category form</span></a>
								
									<a href="product_items_form.php"><span class="glyphicon glyphicon-star">&nbsp;product item form</span></a>
										<!-- <a href="#"><span class="glyphicon glyphicon-star">&nbsp;Admin Link </span></a> -->
								</div>
								<div class="col-md-6 adminLink">
								<!-- 
	<a href="#"><span class="glyphicon glyphicon-star">&nbsp;Admin Link 5</span></a>
									<a href="#"><span class="glyphicon glyphicon-star">&nbsp;Admin Link 6</span></a>
									<a href="#"><span class="glyphicon glyphicon-star">&nbsp;Admin Link 7</span></a>
 -->	<a href="personpcf2.php"><span class="glyphicon glyphicon-star">&nbsp;person product category form</span></a>
									<a href="display_all_products.php"><span class="glyphicon glyphicon-star">&nbsp;display all products</span></a>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</body>
</html>