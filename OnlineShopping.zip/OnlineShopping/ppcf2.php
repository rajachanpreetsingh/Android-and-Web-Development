<?php 
include('refrence.php');
?>
<?php

if(isset($_POST['update'])){
$name = ucwords(trim($_POST['productname']));
if(isset($_POST['status'])){
$status = true;
}
else{
$status = false;
}

$upSql = 'update person_product_category set product_name="'.$name.'",is_active="'.$status.'",main_category_id="'.$category.'" where id='.$_GET['subcategoryid'];


include('config.php');
$resupd = mysql_query($upSql);
if($resupd){
header('Location:allpersonproductcategory.php');
}
else{
echo mysql_error();
}
}
?>
<?php
if (isset($_GET['subcategoryid'])){
$sel="select * from person_product_category where id=".$_GET['main_category_id'];
include('config.php');
$msr=mysql_query($sel);
$ms = mysql_fetch_array($msr);

}
include('refrence.php'); 
?>

<body>
<div class="container"> 
   <div class="row"> 
     <div class="col-lg-12">
     	<div class="well">
     		<h2 class="text-center"> Person product Category form </h2>
     	</div>
     </div>
          <div class="col-lg-12"> 
            <?php
          if(isset($_GET['subcategoryid'])){
          	 $action = '';
          }
          else{
          	$action = 'action="insertpersonproductcategory.php"';	
          }
          
          ?>
        
               <form class="form-inline" method="post" <?php echo $action;?>>
               <div class="col-md-12">
               		<div class="col-md-4">
               			<div class="form-group">
    						<label>Product Name</label>
    						<?php
    							if(isset($ms['product_name'])){
    								$catname=$ms['product_name'];
    							}
    							else{
    								$catname='';
    							}
    						?>
    						<input type="text" class="form-control" name="productname" value="<?php echo $catname;?>">
 						 </div>
    						
  					</div>
     
               		
               		<div class="container"> 
   <div class="row"> 
     <div class="col-lg-12"><br><br>
               			
               				<label for="isactive">Status</label>
               				 <input type="checkbox" name="status" <?php if(isset($check)) echo $check;?>> Is Active
               			</div>
    		
    			     </div>
    					
    					<?php
    	  					if(isset($ms['is_active']) && $ms['is_active']==1){
    							$check = 'checked';
    						}
    						else{
    							$check='';
    						}
    					?>
   					
  					</div> 
  
    					
  					</div> 
  					 <div class="col-md-12">
               		<div class="col-md-4">
               			<div class="form-group"><br><br>
    						<label>Person Category Name</label>
  <?php
    							if(isset($ms['product_name'])){
    								$catname=$ms['product_name'];
    							}
    							else{
    								$catname='';
    							}
    						?>
    						<input type="text" class="form-control" name="productname" value="<?php echo $catname;?>">
 						 </div>
</form>
               	<br>
               	<div class="container"> 
               <div class="row"> 
              <div class="col-lg-12"><br><br>
               				<?php
  								if(isset($_GET['subcategory'])){
									echo '<button type="submit" name="update" class="btn btn-warning">Update</button>'; 
  								}
  								else{
  									echo '<button type="submit" name="createcategory" class="btn btn-success">Submit</button>&nbsp;
  									<button type="reset" class="btn btn-default">Reset</button>';
  								}
  							?>
               			</div>
               		</div>
               		</div>
               		
               </div>
  
  
 
          </div>
     </div>
</div>

</body>