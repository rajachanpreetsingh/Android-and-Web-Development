<?php
include('refrence.php');
 if(isset($_GET['item_id'])){
 $itemid=$_GET['item_id'];
 }
 else{
 header('Location:product_items_form.php');
 
 }


?>

<body>
<div class="container"> 
   <div class="row"> 
     <div class="col-lg-12">
     	<div class="well">
     		<h2 class="text-center">SIZE QUANTITY FORM </h2>
     	</div>
     </div>
     <div class="col-lg-12">
     	<form class="form-horizontal" method="post" action="insert_size_quantity.php">
  <div class="form-group">
    <label  class="col-sm-2 control-label">Item Name</label>
    <div class="col-sm-4">
      					
     	<select name="productcategory" class="form-control" required  >
     		<option value="">SELECT</option>
     <?php
     
     $sql="select * from product_items where is_active=1 ";
     
     
     include('config.php');
     $res=mysql_query($sql);
     if(mysql_num_rows($res)>0)
     {
     while($fetch=mysql_fetch_array($res)){
     ?> 
     <?php
     	if($fetch['itemid'] == $itemid){
     		$sel = 'selected';
     	}
     	else{
     		$sel = '';
     	}
     
     ?>
     
     <option value="<?php echo $fetch['itemid'];?>" <?php if(isset($sel)) echo $sel;?>> <?php echo $fetch['item_name'] ;?></option>
     <?php
     }
     }
     ?>
     </select>
    </div>
  </div>
  
  <div class="form-group">
    <label  class="col-sm-2 control-label"> Select Size</label>
    <div class="col-sm-4">
    <select name="size[]" class="form-control" multiple required >
     		<option value="6">6</option>
     		<option value="7">7</option>
     		<option value="8">8</option>
     		</select>
    
    </div>
  </div>
  
  <div class="form-group">
    <label  class="col-sm-2 control-label">Available Quantity</label>
    <div class="col-sm-4">
      <input type="text" class="form-control" name="availablequantity"  required>
    </div>
  </div>
  
    

  <div class="form-group">
    <div class="col-sm-offset-2 col-sm-4">
     <button type="submit" name="create" class="btn btn-success">Submit</button>&nbsp;
  <button type="reset" class="btn btn-default">Reset</button>  
    </div>
  </div>
</form>	
     </div>
 </div>
</div>
</body>