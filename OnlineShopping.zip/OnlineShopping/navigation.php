<?php
	
	if(isset($_SESSION['Login']))
	{
		$currentUser = $_SESSION['Login'];
		
		include('config.php');
		$query = "select concat(user_register.first_Name,' ',user_register.last_Name)as name from user_register where user_ID='".$currentUser."'";
		
		$result = mysql_query($query);
		
		if(mysql_num_rows($result) > 0)
		{
			
			while($fetch = mysql_fetch_array($result))
			{
		        
				$uid = $fetch['name'];
				
			}
			
			
			
		}
		else{
			
			echo 'false'.mysql_error() ;
		}
		
		$link = '<a style="color:white" href="logout.php"><i style="color:white;padding:14px;" class="glyphicon glyphicon-off"></i>Logout</a>';
	}
	else{
		
		$link = '<a style="color:rgba(193, 255, 20, 0.8);padding:15px;" href="login.php">USER LOGIN</a>';
		$uid="";
	}
	
	
?>
<style>
	body{
	padding-top: 70px;
	}
	
	</style>
<nav class="navbar navbar-inverse navbar-fixed-top">
	<div class="container-fluid">
		<div class="navbar-header">
			<button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-2">
				<span class="sr-only">Toggle navigation</span>
				<span class="icon-bar"></span>
				<span class="icon-bar"></span>
				<span class="icon-bar"></span>
			</button>
			<a class="navbar-brand" href="display_all_products.php" style="font-size:30px;font-style:initial;font-family:initial;font-style:initial;color:orange;text-shadow: 1px 1px green;"> Welcome Online Shoping   </a>
		</div>
		
		<div class="collapse navbar-collapse" id="bs-example-navbar-collapse-2" style="color:red;font-family:initial;font-size:20px;">
			<ul class="nav navbar-nav">
				<li class="dropdown">
				
					<a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false" style="font-size:25px;">MEN<span class="caret"></span></a>
					<ul class="dropdown-menu" role="menu">
						
						<?php
							
							include('config.php');
							
							$query = "select *  from person_product_category where is_active=1 and main_Category_ID=7";
							
							$result = mysql_query($query);	
							
							if(mysql_num_rows($result) > 0)
							{
								
								while($fetch = mysql_fetch_array($result))
								{
								?>
								<li class="menProdCatgry" prodCatId="<?php echo $fetch['subcategoryID']; ?>"><a href="#"><?php echo $fetch['product_name']; ?></a></li>
								<li class="divider"></li>
								<?php
								}
								
							}	
						?>
						
					</ul>
				</li>
				
				
				
				
				<li class="dropdown">
					<a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false" style="font-size:25px;">WOMEN<span class="caret"></span></a>
					<ul class="dropdown-menu" role="menu">
						
						<?php
							
							include('config.php');
							
							$query = "select *  from productcategory where isActive=1 and mainCategoryID=2";
							
							$result = mysql_query($query);	
							
							if(mysql_num_rows($result) > 0)
							{
								
								while($fetch = mysql_fetch_array($result))
								{
								?>
								<li class="womenProdCatgry" prodCatId="<?php echo $fetch['categoryID']; ?>"><a href="#"><?php echo $fetch['productname']; ?></a></li>
								<li class="divider"></li>
								<?php
								}
								
							}	
						?>
						
					</ul>
				</li>
				
				
				
				<li class="dropdown">
					<a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false" style="font-size:25px;" >KIDS<span class="caret"></span></a>
					<ul class="dropdown-menu" role="menu">
						<?php
							
							include('config.php');
							
							$query = "select *  from productcategory where isActive=1 and mainCategoryID=14";
							
							$result = mysql_query($query);	
							
							if(mysql_num_rows($result) > 0)
							{
								
								while($fetch = mysql_fetch_array($result))
								{
								?>
								<li class="kidsProdCatgry" prodCatId="<?php echo $fetch['categoryID']; ?>"><a href="#"><?php echo $fetch['productname']; ?></a></li>
								<li class="divider"></li>
								<?php
								}
								
							}	
						?>
					
						
					</ul>
				</li>
				
			</ul>
			
			
			
			<ul class="nav navbar-nav navbar-right" style="color:white;">
			
			<i style="color:#0FAAFC;padding:14px;margin:inherit;" class="glyphicon glyphicon-user"></i><?php echo $uid;?>
			<?php echo $link;?>
				</ul>
		</div>
		
	</div>
</nav>
<script>
	$(document).ready(function(){
		$('body').on('click','.menProdCatgry',function(){
			// alert( $(this).attr('prodCatId'));
			$.ajax({
				type: "post",
				url: "getselectedproducts.php",
				data:{
					"prodId" : $(this).attr('prodCatId')
				},
				dataType: "json",
				success: function(data){
				$('#result').html('');
				console.log(data);
				$.each(data, function(){
					var getprodId = this.prodId;
					var getimageURL = this.imageURL;
					var getprice = this.Price;
					var getitemName = this.itemName;
					var getitemID = this.itemID;
					
					
					
					var f='<div class="col-sm-4"><div class="thumbnail"><a class="productitemid" href="product_purchase.php?id='+getitemID+'"><img class="img-responsive productimage" src="uploadedfiles\/'+getimageURL+'" alt="'+getimageURL+'" /></a><div class="text-center productitemname" style="font-weight:bold;">'+getitemName+'</div><div class="badge col-sm-offset-1 productprice">'+getprice+'</div><span class="col-md-offset-7"><a class="productitemid btn btn-success" href="productpurchase.php?id='+getitemID+'" class="btn btn-success" >BUY</a></span></div></div>';
					$('#result').append(f);
				});
				
			},
			error: function(data){
				console.log(data);
			}
		});
	});
	});
</script>