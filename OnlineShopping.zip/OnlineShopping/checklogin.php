<?php
	
	include('config.php');
	
	$eml = $_POST['email'];
	$psd = $_POST['paswd'];
	
	$query = "select user_id, email, password from user_register where email = '".$eml."' and password = '".$psd."'";
	
	$result = mysql_query($query);
	
	if(mysql_num_rows($result) > 0)
	{
		$loginArray = [];
		while($fetch = mysql_fetch_array($result))
		{
			$uid = $fetch['user_id'];
			
		}
		session_start();
		$_SESSION['Login'] = $uid;
		
		echo 'true';
		
	}
	else{
		// echo 'false';
		echo 'false'.mysql_error() ;
	}
?>