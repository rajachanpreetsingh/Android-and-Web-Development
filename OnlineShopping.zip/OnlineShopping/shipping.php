<?php
	session_start();
	if(isset($_SESSION['Login'])){
	$lastInsId = $_SESSION['Login'];
	include('config.php');
    $namequery="select CONCAT(first_name, ' ',last_name) as name, mobile, email from user_register where user_id='".$lastInsId."'";
	$result1 = mysql_query($namequery);
	
	while($fetch = mysql_fetch_array($result1)){
		$c_name = $fetch['name'];
		$c_email = $fetch['email'];
		$c_mobile=$fetch['mobile'];
	}	
	}

		$checkaddress="select(case when count(1)>0 then 'true' else 'false' end) as IsExist from adress where user_id='".$lastInsId."'";
	    $res=mysql_query($checkaddress);
	if ($res='ture'){
	$selectaddress="SELECT address.* from address WHERE user_id='".$lastInsId."'";
	$res1=mysql_query($selectaddress);
	while($getadd=mysql_fetch_array($res1)){
	$add1=$getadd['address1'];
	$add2=$getadd['address2'];
	$add3=$getadd['address3'];
	}
	
	}

	
	if(isset($_SESSION['address1'])){
		$cnfrmAddress1 = $_SESSION['address1'];
	}
	else{
		$cnfrmAddress1 = '';
	}
	if(isset($_SESSION['address2'])){
		$cnfrmAddress2 = $_SESSION['address2'];
	}
	else{
		$cnfrmAddress2 = '';
	}
	if(isset($_SESSION['address3'])){
		$cnfrmAddress3 = $_SESSION['address3'];
	}
	else{
		$cnfrmAddress3 = '';
	}	
	
	
	
	include('refrence.php');
	include('navigation.php');
	
?>
<style>
	body{
	background:url('images/imagess.jpg');
	}
</style>
<div class="container" style="margin-top:10px;">
	<div class="row">
		<div class="col-md-8 well" style="margin-left:15%;background-color:hsl(207, 74%, 88%)">
		<div style="background-color:#337AB7;font-size:30px;text-align:center;color:white;font-style:italic;">SHIPPING DETAILS</div><br>
		<form class="form-horizontal"  method="POST" action="insertaddress.php" style="margin-left:5%;">
			<div class="form-group">
				<label for="select" class="col-lg-3 control-label">ZIP CODE</label>
				<div class="col-lg-6">
					
					<select id="zipcd" name="zipcode" class="form-control" required>
						<option value="">SELECT</option>
						<?php
							
							include('config.php');
							
							$query = "select zipcode,zipCodeID from zipcode";
							
							$result = mysql_query($query);	
							
							if(mysql_num_rows($result) > 0)
							{
								
								while($fetch = mysql_fetch_array($result))
								{
								?>
								<option value = <?php echo $fetch['zipCodeID']; ?>><?php echo $fetch['zipcode']; ?></option>	
								<?php
								}
								
							}	
						?>
					</select>
				</div>
			</div>
			
			<div class="form-group" > 
				<label for="inputText" class="col-lg-3 control-label">NAME</label>
				<div class="col-lg-6">
					<input type="text" class="form-control" name="name" value="<?php echo $c_name; ?>" placeholder="name" required>
				</div>
			</div>
			<div class="form-group">
				<label for="inputEmail" class="col-lg-3 control-label">E-MAIL</label>
				<div class="col-lg-6">
					<input type="text" class="form-control" name="email"  value="<?php echo $c_email; ?>" placeholder="email" required>
				</div>
			</div>
			<div class="form-group">
				<label for="inputEmail" class="col-lg-3 control-label">ADDRESS 1</label>
				<div class="col-lg-6">
					<input type="text" class="form-control" value="<?php if(isset($add1)) echo $add1; ?>" name="address1" placeholder="address1" required>
				</div>
			</div>
			<div class="form-group">
				<label for="inputEmail" class="col-lg-3 control-label">ADDRESS 2</label>
				<div class="col-lg-6">
					<input type="text" class="form-control" value="<?php if(isset($add2)) echo $add2; ?>"name="address2" placeholder="address2">
				</div>
			</div>
			<div class="form-group">
				<label for="inputEmail" class="col-lg-3 control-label">ADDRESS 3</label>
				<div class="col-lg-6">
					<input type="text" class="form-control" value="<?php if(isset($add3)) echo $add3; ?>" name="address3" placeholder="address3">
				</div>
			</div>
			
			<div class="form-group">
				<label for="inputEmail" class="col-lg-3 control-label">STATE</label>
				<div class="col-lg-6">
					<input type="text" class="form-control" id="state" name="state" placeholder="state">
				</div>
			</div>
			
			
			
			<div class="form-group">
				<label for="inputEmail" class="col-lg-3 control-label">CITY</label>
				<div class="col-lg-6">
					<input type="text" class="form-control" id="city" name="city" placeholder="city">
				</div>
			</div>
			
			
			
			<div class="form-group" > 
				<label for="inputText" class="col-lg-3 control-label">MOBILE</label>
				<div class="col-lg-6">
					<input type="number" max="9999999999" min="1111111111" value="<?php echo $c_mobile; ?>" class="form-control" name="mobile" placeholder="mobile" required>
				</div>
			</div>
			
				
			
			<div class="form-group">
				<div class="col-lg-10 col-lg-offset-4">
					<button type="reset" class="btn btn-default" >CANCEL</button> 
					<button type="submit" style="margin-top:0px;"class="btn btn-primary">PROCEED</button>
					<!--<a href="confirmation.php" type="submit" class="btn btn-primary">PROCEED</a>-->
				</div>
			</div>
			
			
			
		</form>
	</div>
</div>
</div>
<script>
	$(document).ready(function(){
		
		$('#zipcd').change(function(){
			
			
			$.ajax({
				type: "post",
				url: "statecity.php",
				data:{
					"zipcode" : $('#zipcd').val()
					
				},
				dataType: "json",
				success: function(data){
					
					$.each(data, function(){
						var getCity = this.City;
						var getState = this.State;
						$('#city').val(getCity);
					    $('#state').val(getState);
					});
					
					
					
				},
				error: function(data){
					console.log(data);
				}
				
			});
			
			
			
			
		});
	});
</script>


</body>
