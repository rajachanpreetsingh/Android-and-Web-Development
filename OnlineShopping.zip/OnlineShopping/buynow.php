<?php
	session_start();
	if(isset($_SESSION['ProductItemId']))
	{
		$itemId = $_SESSION['ProductItemId'];
	}
	include('refrence.php');
	include('navigation.php');
	
	 $size = $_POST['selectedsize'];
	 $_SESSION['selectedsize'] = $size;
	 $quant = $_POST['quantity'];
	 $_SESSION['quantity'] = $quant;
	
	
	if(isset($_SESSION['']))
{
	unset($_SESSION['']);
	session_destroy();
	header('Location:/project/images.php');
}
	
	
?>
<?php
	if(!isset($_SESSION['Login']))
	{
		$proceedForOrderBtn = '<a href="login.php" class="btn btn-sm btn-success sendMail" style="margin-left:25%"><i class="glyphicon glyphicon-ok"></i>&nbsp;&nbsp;PROCEED FOR ORDER</a>';
	}
	else{
	    $proceedForOrderBtn = '<a href="confirmation.php" class="btn btn-sm btn-success sendMail" style="margin-left:25%"><i class="glyphicon glyphicon-ok"></i>&nbsp;&nbsp;PROCEED FOR ORDER</a>'; 
	
	}
	
	?>
<style>
	body{
	background:url('images/imagess.jpg');
	}
</style>

<div class="container" style="margin-top:5%;">
	<div style="font-size:40px;font-family:cursive;font-weight:bold;color:black">SHOPPING CART</div>
	
	<div class="col-md-12 well" style="background-color:LightGoldenRodYellow;">
		
		<?php
			include('config.php');
			
			
			$query ="select product_items.itemid, product_items.item_name, product_items.price,product_items.image_url, product_items.date_created,product_items.brand_name from product_items where product_items.itemid='".$itemId."' and product_items.is_active=1 and product_items.is_item_available=1";
			
			$result = mysql_query($query);	
			
			if(mysql_num_rows($result) > 0)
			{
				
				while($fetch = mysql_fetch_array($result))
				{
					$_SESSION['productPrice'] = $fetch['price'];
					$_SESSION['item_name'] = $fetch['item_name'];
				?>
				
				
				<div class="col-md-2">
					<a href="productpurchase.php?id=<?php echo $fetch['itemID'];?>">
					<img class="img-responsive img-rounded" src="uploadedfiles\<?php echo $fetch['image_url'];?>" alt="<?php echo $fetch['image_url']; ?>"  style=""></a>
					
				</div>
				
				
				<div class="col-md-3">
					<div style="text-align:right;margin-right:10%;">
						<span style="font-size: 16px;font-weight:bold;"><?php echo $fetch['brand_name']; ?></span><br><br>
						<span style="font-weight:bold;font-size:12px;color:black;margin-top:20%;"><?php echo $fetch['item_name']; ?></span>
					</div>
					
				</div>
				
				<div class="col-md-1">
					<label for="inputText"  style="font-size:15px;color:#286090;margin-right:55%;font-style:bold;">SIZE</label><br>
				<span style="margin-right:65%;font-weight:bold;"><?php echo $size;?></span><br></div>
				
				<div class="col-md-2">
					<label for="inputText"  style="font-size:15px;color:#286090;margin-right:50%;">PRICE</label><br>
					<span style="font-size:15px;margin-right:45%;font-weight:bold;"><?php echo"&#8377";?>&nbsp<?php echo $fetch['price']; ?>
						
					</span>
				</div>
				
				
				<div class="col-md-2">
					<label for="inputText"  style="font-size:15px;color:#286090;margin-right:50%;">QUANTITY</label><br>
					<span style="margin-right:65%;font-weight:bold;"><?php echo $_POST['quantity'];?></span>
					
					
				</div>
				
				<div class="col-md-2">
					<label for="inputText"  style="font-size:15px;color:#286090;margin-right:50%;font-weight:bold">TOTAL</label><br>
					<?php
						echo "&#8377";
					?>
					<?php
						$x=$fetch['price'];
						$y=$_POST['quantity'];
						$z=$x*$y;
						echo "$z";
						
						$_SESSION['productAmount'] = $z;
					?>
					
					
				</div>
				
				
				
				
				<div class="col-lg-7 col-lg-offset-3 ">
					<div style="margin-left:15%;margin-top:15%">
						<a  style="margin-top:%" href="productpurchase.php?id=<?php echo $itemId;?>&selectedsize=<?php echo $size;?>&quan=<?php echo $quant;?>" class="btn btn-sm btn-primary"><i class="glyphicon glyphicon-pencil"></i>&nbsp;&nbsp;EDIT ITEM</a> 
						<button type="submit" style="margin-top: 16px;"class="btn btn-sm btn-danger"><i class="glyphicon glyphicon-trash"></i>&nbsp;&nbsp;REMOVE</button>
						
						<?php echo $proceedForOrderBtn;?>
						
						
						
						
					</div>
				</div>
				
				
				
				
			</div>
			
			 
			
			
			
			<?php
			}
		}	
	?>
</div>
</div>
</body>	
