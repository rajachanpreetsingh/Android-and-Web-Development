<?php
	
	include('refrence.php');
	
?>
<style>
	.em-sc
	{
	color:green;
	font-size:11px;
	font-weight:normal;
	}
	.em-er
	{
	color:Red;
	font-size:11px;
	font-weight:normal;
	}
	
	
</style>
<style>
	body{
	background:url('images/imagess.jpg');
	}
</style>
<div class="container" style="margin-top:40px;">
	<div class="row">
		<div class="col-md-8 well" style="margin-left:15%;background-color:hsl(207, 74%, 88%);">
			<div class="text-center" style="background-color:#337AB7;font-size:30px;text-align:center;color:white;font-style:italic;">USER REGISTRATION</div><br>
			<form class="form-horizontal"  method="POST" action="insertuserregistration.php">
				<div class="form-group" > 
					<label for="inputText" class="col-lg-3 control-label">FIRST NAME</label>
					<div class="col-lg-6">
						<input type="text"  class="form-control"  name="firstName" placeholder="firstname" required>
					</div>
				</div>
				
				<div class="form-group" > 
					<label for="inputText" class="col-lg-3 control-label">LAST NAME</label>
					<div class="col-lg-6">
						<input type="text" class="form-control" name="lastName" placeholder="lastname" required>
					</div>
				</div>
				
				<div class="form-group" > 
					<label for="inputText" class="col-lg-3 control-label">MOBILE</label>
					<div class="col-lg-6">
						<input type="number" max="9999999999" min="1111111111"class="form-control" name="mobile" placeholder="mobile"required>
					</div>
				</div>
				
				
				<div class="form-group">
					<label for="inputEmail" class="col-lg-3 control-label">E-MAIL</label>
				<div class="col-lg-6">
				<input type="email" autocomplete="off" class="form-control" name="Email" id="email" placeholder="Email" required>
				<img id="loader" src="C:\xampp\htdocs\PROJECT\images\loading1.gif" alt="loading">
				<div id="confirmMsg"></div>
				</div>
				</div>
				
				<div class="form-inline">
				<label class="col-lg-3 control-label">GENDER</label>
				<div class="col-lg-7">
				<div class="radio">
				<label>
				<input type="radio" name="gender"  value="male">
				male
				</label>
				</div>
                <div class="radio">
				<label>
				<input type="radio" name="gender"  value="female">
				female
				</label>
                </div>
				</div>
				</div>
				
				
				<div class="form-group">
				<label for="inputPassword" class="col-lg-3 control-label">PASSWORD</label>
				<div class="col-lg-6">
				<input type="password" class="form-control" name="password" placeholder="Password">
				</div>
				
				
				<div class="form-group">
				<div class="col-lg-10 col-lg-offset-4"><br>
				
				<button type="reset" class="btn btn-default" >Cancel</button> 
				<button type="submit" class="btn btn-primary">Submit</button>
				</div>
				</div>
				
				
				
				</form>
				</div>
				</div>
				</div>
				<script>
				$(document).ready(function(){
				$('#loader').hide();
				$("#email").blur(function(){
				$("#loader").show();
				$.ajax({
				type:"Post",
				data:{
				"Email" : $('#email').val()
				},
				url: "checkemail.php",
				datatype:"json",
				success: function(data){
				
				$('#loader').hide();
				if(data == "false")
				{
				$("#confirmMsg").html('<span class="em-sc">email Valid</span>');
				}
				else
				{	
				$("#confirmMsg").html('<span class="em-er">email already used</span>');
				}
				}
				});
				});
				});
				</script>
				</body>
				</html>				