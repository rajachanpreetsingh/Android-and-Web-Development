<?php
	session_start();
	if(isset($_GET['id']))
	{
		$pid = $_GET['id'];
		$_SESSION['ProductItemId'] = $pid;
	}
	if(isset($_GET['id']) && isset($_GET['selectedsize']) && isset($_GET['quan']))
	{
		$itemId = $_GET['id'];
		$editSize = $_GET['selectedsize'];
		$editQuan = $_GET['quan'];
		// <button type="button" class="btn btn-default get">Get it now</button>
		$btn = '<button type="submit" class="btn btn-success btn-block" style="font-size:26px;Width:80%;"><i class="glyphicon glyphicon-shopping-cart"></i>&nbsp;&nbsp;Update Cart</button>';
	}
	else{
		$editSize = '';
		$editQuan = '';
		$btn = '<button type="submit" class="btn btn-success btn-block" style="font-size:26px;Width:80%;"><i class="glyphicon glyphicon-shopping-cart"></i>&nbsp;&nbsp;BUY NOW</button>';
	}
	include('refrence.php');
	include('navigation.php');
?>

<style>
	body{
	background:url('images/imagess.jpg');
	}
</style>


<div class="container">	
	<div class="col-md-12" style="padding-top:5px;">
		<?php
			include('config.php');
			$query ="select product_items.itemid, product_items.item_name, product_items.price, product_items.image_url, product_items.date_created,product_items.brand_name,
			product_items.type,product_items.fabric, product_items.colour from product_items where product_items.itemid= '".$_GET['id']."' and product_items.is_active=1 and product_items.is_item_available=1";
			$result = mysql_query($query);	
			
			 $query2="select size_quantity.size from size_quantity where itemid='".$_GET['id']."'";
		$result2=mysql_query($query2);
		
		
			
		if(mysql_num_rows($result2) > 0)
		{
			while($fetch2 = mysql_fetch_array($result2))
			{
			$sizearray[] = $fetch2['size'];
		    }
		}
			
			if(mysql_num_rows($result) > 0)
			{
				while($fetch = mysql_fetch_array($result))
				{
				?>
				<div class="col-md-7">
					<a href="productpurchase.php?id=<?php echo $fetch['itemid'];?>">
					<img class="img-responsive img-rounded" style="margin-left:12%" src="uploadedfiles\<?php echo $fetch['image_url'];?>" alt="<?php echo $fetch['imageURL']; ?>" /></a>
					<br><br><br>
					<div class="col-md-10" id="productItems" style="background-color:aliceblue;margin-top:5%;margin-left:12%;">
						<label for="inputText" class="col-lg-6 control-label" style="font-size:15px;color:grey;margin-left:30%;border-radius:40%;"><u>Product Info</u></label>	<br><br>	 
						<label for="inputText" class="col-lg-6 control-label" style="font-size:15px;color:grey;margin-left:10%;">TYPE</label>
						<span style="font-size:15px;"> <?php echo $fetch['type']; ?></span><br><br>
						<label for="inputText" class="col-lg-6 control-label" style="font-size:15px;color:grey;margin-left:10%;">FABRIC</label>
						<span style="font-size:15px;"> <?php echo $fetch['fabric']; ?></span><br><br>
						
						<label for="inputText" class="col-lg-6 control-label" style="font-size:15px;color:grey;margin-left:10%;">COLOUR</label>
						<span style="font-size:15px;"> <?php echo $fetch['colour']; ?></span><br><br>
					
						
					</div>
					
				</div>
				
				<div class="col-md-5" >
					
					<span style="font-size:40px;font-family:cursive;font-weight:bold;color:black"><?php echo $fetch['brand_name']; ?></span><br><br>
					<span style="font-weight:bold;font-style:italic;font-size:20px;color:black;margin-top:20%;font-family:cursive;text-shadow:3px 3px 10px #EA0000;;"><?php echo $fetch['item_name']; ?></span><br><br>
					<a href="#productItems" class="productInfo" style="margin-right:33%;font-size:15px;font-family:cursive;font-weight:bold;color:black;">Product Info</a><br>
					<span style="font-size:35px;margin-right:25%;font-family:cursive;color:black;"><?php echo"&#8377";?>&nbsp<?php echo $fetch['price']; ?></span><br><br>
						<span style="font-size:15px;font-family:cursive;font-weight:bold;margin-right:40%;color:black;">Select Size</span><br><br>
						<form action="buynow.php" method="post" id="buyform">
							<?php
								//$str = $fetch['size'];
								//$output = explode(", ",$sr);
								foreach($sizearray as $x){
								?>
								<span class="size-select sizeOptions" sizeValue="<?php echo $x; ?>" style="width:50px;height:50px;padding:10px 15px;margin:0 5px 5px 0;border: 1px solid black;background-color:rgb(133, 169, 169);font-size:20px;margin-right:15px;">
								<?php echo $x; ?></span>
								<?php
								}?>
								<br><br>
								<span id="show" style="color:red;margin-right:26%;">This is a required field.</span><br>
								<div style="font-size:15px;font-weight:bold;font-family:cursive">Select Quantity:</div>
								<div><input type="number" class="form-control" name="quantity" min="1" max="100" value="<?php echo $editQuan;?>" style="width:40%;" id="selectquantity">
									<span id="show1" style="color:red;margin-right:35%;">Select quantity.</span><br>
									<input type="hidden" name="selectedsize" value="<?php echo $editSize;?>" id="selectedsize">
									
									<?php echo $btn;?>
									
								</form>
						</div>
						<?php
						}
					}	
				?>
				
			</div>
		</div>
		
		
		<script>
			$(document).ready(function(){
				$('#show').hide();
				$('#show1').hide();
				
				$("body").on("click",".sizeOptions", function(){
				
				//$('.sizeOptions').removeAttr('selected');
				$('.sizeOptions').css('background-color','#85A9A9');
				$(this).attr('selected',true);
				if($(this).attr('selected')){
					$(this).css('background-color','skyblue');
				}
				
					var x=	$(this).attr("sizeValue");
					
					$('#selectedsize').val(x);
				});
				$('#buyform').submit(function(e){
					var y = $('#selectedsize').val();	
					if (y == "")
					{
						$('#show1').show();
						$('#show').show();
						return false;
					}
					else	
					{
						return true;
					}			  
					return false;
				});
				
			});
		</script>
	</body>
	
	
	
