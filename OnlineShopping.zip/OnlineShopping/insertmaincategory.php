<?php

if(isset($_POST['createcategory'])){
$name = ucfirst(trim($_POST['categoryname']));
if(isset($_POST['status'])){
$status = true;
}
else{
$status = false;
}
$sql = "insert into person_category(category_name,is_active)";
$sql .= " values('".$name."','".$status."')";
include('config.php');
$res = mysql_query($sql);
if($res){

header('Location:allmaincategories.php');
}
else{
echo mysql_error();
}
}
?>