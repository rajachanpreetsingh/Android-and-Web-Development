<?php
	include("Config.php");
	$Email="";
	$Email=$_POST['Email'];
	$selectMail="select(case when count(1)>0 then 'true' else 'false' end) as IsExist from user_register where email='".$Email."'";
	$selectMailResult=mysql_query($selectMail);
	if(mysql_num_rows($selectMailResult) > 0)
	{
		while($fetch = mysql_fetch_array($selectMailResult))
		{
			$res=$fetch['IsExist'];
		}
	}			
	echo $res;	
?>