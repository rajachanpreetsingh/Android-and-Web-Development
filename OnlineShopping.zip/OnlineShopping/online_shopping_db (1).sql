-- phpMyAdmin SQL Dump
-- version 4.2.11
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Aug 31, 2015 at 01:18 PM
-- Server version: 5.6.21
-- PHP Version: 5.6.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `online_shopping_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `city`
--

CREATE TABLE IF NOT EXISTS `city` (
`cityID` int(11) NOT NULL,
  `cityName` varchar(255) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `city`
--

INSERT INTO `city` (`cityID`, `cityName`) VALUES
(1, 'A.I.O Donna paul'),
(2, 'Adur'),
(3, 'Agra'),
(4, 'Ahemdabad'),
(5, 'Alwar'),
(6, 'Bathala'),
(7, 'begusaral'),
(8, 'bargarh'),
(9, 'Beed'),
(10, 'Borholla'),
(11, 'Bijapur'),
(12, 'Addanki');

-- --------------------------------------------------------

--
-- Table structure for table `state`
--

CREATE TABLE IF NOT EXISTS `state` (
`stateID` int(11) NOT NULL,
  `stateName` varchar(255) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `state`
--

INSERT INTO `state` (`stateID`, `stateName`) VALUES
(2, 'Goa'),
(3, 'kerala'),
(4, 'Uttar Pradesh'),
(5, 'Calcutta'),
(6, 'Rajasthan'),
(7, 'Punjab'),
(8, 'Bihar'),
(9, 'Orissa'),
(10, 'Maharashtra'),
(11, 'Nagaland'),
(12, 'Karnatka'),
(13, 'Andhra Pradesh');

-- --------------------------------------------------------

--
-- Table structure for table `zipcode`
--

CREATE TABLE IF NOT EXISTS `zipcode` (
`zipCodeID` int(11) NOT NULL,
  `zipCode` varchar(255) NOT NULL,
  `cityID` int(11) NOT NULL,
  `stateID` int(11) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `zipcode`
--

INSERT INTO `zipcode` (`zipCodeID`, `zipCode`, `cityID`, `stateID`) VALUES
(6, '403004', 1, 2),
(7, '691523', 2, 3),
(8, '282001', 3, 4),
(9, '380001', 4, 5),
(10, '301001', 5, 6),
(11, '151001', 6, 7),
(12, '851101', 7, 8),
(13, '768028', 8, 9),
(14, '431122', 9, 10),
(15, '798631', 10, 11),
(16, '586101', 11, 12),
(17, '523201', 12, 13);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `city`
--
ALTER TABLE `city`
 ADD PRIMARY KEY (`cityID`);

--
-- Indexes for table `state`
--
ALTER TABLE `state`
 ADD PRIMARY KEY (`stateID`);

--
-- Indexes for table `zipcode`
--
ALTER TABLE `zipcode`
 ADD PRIMARY KEY (`zipCodeID`), ADD KEY `cityID` (`cityID`), ADD KEY `stateID` (`stateID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `city`
--
ALTER TABLE `city`
MODIFY `cityID` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=13;
--
-- AUTO_INCREMENT for table `state`
--
ALTER TABLE `state`
MODIFY `stateID` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=14;
--
-- AUTO_INCREMENT for table `zipcode`
--
ALTER TABLE `zipcode`
MODIFY `zipCodeID` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=18;
--
-- Constraints for dumped tables
--

--
-- Constraints for table `zipcode`
--
ALTER TABLE `zipcode`
ADD CONSTRAINT `zipcode_ibfk_1` FOREIGN KEY (`cityID`) REFERENCES `city` (`cityID`),
ADD CONSTRAINT `zipcode_ibfk_2` FOREIGN KEY (`stateID`) REFERENCES `state` (`stateID`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
