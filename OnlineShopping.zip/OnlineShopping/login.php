<?php
	session_start();
	if(!isset($_SESSION['ProductItemId']))
	{
		$shwBuyMsg = '<div class="col-md-6 col-md-offset-3 alert alert-danger text-center">Please select atleast one product. Click <a href="display_all_products.php">here</a> to check catalog.</div>';
		$displayStatus = true;
	}
	else{
		$shwBuyMsg = '';
		$displayStatus = false;
		
	}
	include('refrence.php');
	include('navigation.php');
	
	
?>

<style>
	body{
	background:url('images/imagess.jpg');
	}
</style>

<div class="container" style="margin-top:40px">
	<div class="row" id="result">
	<input type="hidden" value="<?php echo $displayStatus;?>" id="displayStatus">
	<?php
		echo $shwBuyMsg;
		?>
		<div class="col-md-8 well" style="margin-left:15%;background-color:hsl(207, 74%, 88%)">
			<div class="text-center" style="background-color:#337AB7;font-size:30px;text-align:center;color:white;font-style:italic;"> USER LOGIN</div>
			<form action="" method="post" id="loginform" class="form-horizontal">
				<span id="reqdMsg" style="color:red;">Form Fields are required.</span><br>
				<span id="loginMsg" style="color:red;">Invalid login.</span><br>
				<div class="form-group">
					<label for="inputEmail" class="col-lg-2 control-label" >E-MAIL</label>
					<div class="col-lg-7">
						<input type="text" name="email" id="uemail" class="form-control" placeholder="email"><br>
					</div>
				</div>
				<div class="form-group">
					<label for="inputPassword" class="col-lg-2 control-label">PASSWORD</label>
					<div class="col-lg-7">
						<input type="password" name="paswd" id="upaswd" class="form-control" placeholder="password"><br>
					</div>
				</div>
				<div class="form-group">
					<div class="col-lg-10 col-lg-offset-3">
						<input type="reset" class="btn btn-default" value="CANCEL" style="margin-top:2%">
						<input type="submit" name="submit" id="btn" class=" btn btn-primary" value="LOGIN">
						
						
						
						
						
					</div>
				</div>
				<br><br>
				
				<a href="userregistration.php"><b>For New Registration,Click Here !<b></a>
					
				</form>
				</div>
			</div>	
			
			
			
			
		
			<script>
				$(document).ready(function(){
				// $(document).ajaxStart(function () {
// 
//         NProgress.start();
//         
// 
//     }).ajaxStop(function () {
//         
//         NProgress.done();
//         
//     });
				var dispVal = $('#displayStatus').val();
				if(dispVal == 1){
					$("#loginform :input").prop("disabled", true);
				}
				else{
					$("#loginform :input").prop("disabled", false);
				}
					$('#reqdMsg').hide();
					$('#loginMsg').hide();
					$('#btn').click(function(e){
						
						e.preventDefault();
						
						var ueml = $('#uemail').val();
						var upsw = $('#upaswd').val();
						
						if(ueml == ''||upsw == ''){
							$('#reqdMsg').show();
							return false;
						}
						else{
							$.ajax({
								type: "post",
								url: "checklogin.php",
								data:{
									"email" : $('#uemail').val(),
									"paswd" : $('#upaswd').val()
								},
								dataType: "json",
								success: function(data){
									alert(data);
									if(data.toString() == "true"){
										window.location = "shipping.php";
									}
									else{
										
										$('#loginMsg').show();
									}
								},
								error: function(data){
									console.log(data);
								}
								
							});
						}
						
					});
					
				});
			</script>
			<script>
			// $(document).ajaxStart(function () {
// 
//         NProgress.start();
//         
// 
//     }).ajaxStop(function () {
//         
//         NProgress.done();
//         
//     });
	</script>
			
		</body>
		