<?php
	session_start();
	if(isset($_SESSION['ProductItemId']))
	{
		$itemId = $_SESSION['ProductItemId'];
	}
	if(isset($_SESSION['quantity']))
		{
		$quant = $_SESSION['quantity'];
		}
	if(isset($_SESSION['selectedsize']))
		{
		$size = $_SESSION['selectedsize'];
		}
		
		
	 if(!isset($_SESSION['Login']) && $_SESSION['Login']=="")
	 {
	 header('Location:login.php');
	}
	else
	 {
	 $login=$_SESSION['Login']; 
	}	
	
	include('config.php');
	$querymail="select email from user_register where user_ID='".$login."'";
	$result = mysql_query($querymail);
	if(mysql_num_rows($result) > 0)
	{
		while($fetch = mysql_fetch_array($result))
		{
			$email=$fetch['email'];
		}
		$_SESSION['custEmail']= $email;
	}
	else{
		echo mysql_error();
	}
	
	
	
 if(isset($_SESSION['address1'])){
		$cnfrmAddress1 = $_SESSION['address1'];
	}
	else{
		$cnfrmAddress1 = '';
	}
	if(isset($_SESSION['address2'])){
		$cnfrmAddress2 = $_SESSION['address2'];
		}
	else{
		$cnfrmAddress2 = '';
	}
	if(isset($_SESSION['address3'])){
		$cnfrmAddress3 = $_SESSION['address3'];
	}
	else{
		$cnfrmAddress3 = '';
	}
	if(isset($_SESSION['cityname'])){
		$city = $_SESSION['cityname'];
	}
	else{
		$city = '';
	}
	if(isset($_SESSION['statename'])){
		$state = $_SESSION['statename'];
	}
	else{
		$state = '';
	}
	
	if(isset($_SESSION['zipCode'])){
		$zipcode = $_SESSION['zipCode'];
	 }
	 else{
		 $zipcode = '';
	 }
	 
		
	include('refrence.php');
	include('navigation.php');
	
	
	?>
<style>
	body{
	//background:url('images/imagess.jpg');
	}
</style>

<div class="container" style="margin-top:5%;">
	<div style="font-size:40px;font-family:cursive;font-weight:bold;color:black">CONFIRM YOUR ORDER</div>
	
	<div class="col-md-12 well" style="background-color:LightGoldenRodYellow;">
		
		<?php
			include('config.php');
			
			
			$query ="select product_items.itemID, product_items.item_Name, product_items.price,product_items.image_URL, product_items.date_Created,product_items.brand_name from product_items where product_items.itemID='".$itemId."' and product_items.is_Active=1 and product_items.is_Item_Available=1";
			
			$result = mysql_query($query);
			if(is_array($result)){
				echo '1';
			}	
			else{
				echo mysql_error();
			}
			if(mysql_num_rows($result) > 0)
			{
				
				while($fetch = mysql_fetch_array($result))
				{
					$_SESSION['productPrice'] = $fetch['price'];
					$_SESSION['itemName'] = $fetch['item_Name'];
				?>
				
				
				<div class="col-md-2">
					<a href="productpurchase.php?id=<?php echo $fetch['itemID'];?>">
					<img class="img-responsive img-rounded" src="uploadedfiles\<?php echo $fetch['image_URL'];?>" alt="<?php echo $fetch['image_URL']; ?>"  style=""></a>
					
				</div>
				
				
				<div class="col-md-3">
					<div style="text-align:right;margin-right:10%;">
						<span style="font-size: 16px;font-weight:bold;"><?php echo $fetch['brand_name']; ?></span><br><br>
						<span style="font-weight:bold;font-size:12px;color:black;margin-top:20%;"><?php echo $fetch['item_Name']; ?></span>
					</div>
					
				</div>
				
				<div class="col-md-1">
					<label for="inputText"  style="font-size:15px;color:#286090;margin-right:55%;font-style:bold;">SIZE</label><br>
				<span style="margin-right:65%;font-weight:bold;"><?php echo $size;?></span><br></div>
				
				<div class="col-md-2">
					<label for="inputText"  style="font-size:15px;color:#286090;margin-right:50%;">PRICE</label><br>
					<span style="font-size:15px;margin-right:45%;font-weight:bold;"><?php echo"Rs";?>&nbsp<?php echo $fetch['price']; ?>
						
					</span>
				</div>
				
				
				<div class="col-md-2">
					<label for="inputText"  style="font-size:15px;color:#286090;margin-right:50%;">QUANTITY</label><br>
					<span style="margin-right:65%;font-weight:bold;"><?php echo $quant;?></span>
					
					
				</div>
				
				<div class="col-md-2">
					<label for="inputText"  style="font-size:15px;color:#286090;margin-right:50%;font-weight:bold">TOTAL</label><br>
					<?php
						echo "Rs";
					?>
					<?php
						$x=$fetch['price'];
						$y=$quant;
						$z=$x*$y;
						echo "$z";
						$_SESSION['productAmount'] = $z;
					?>
					
					
				</div>
				
				
				
				
				<div class="col-lg-7 col-lg-offset-3 ">
					<div style="margin-left:60%;margin-top:15%;">
						
						<?php
							$paypal_url='https://www.sandbox.paypal.com/cgi-bin/webscr';
							//$paypal_id=''; // Business email ID
							unset($_SESSION['Login']);
						?>
						
						
						
						<form action="<?php echo $paypal_url; ?>" method="post" name="frmPayPal1" id="paypalfrm" >
							<input type="hidden" name="cmd" value="_xclick">
							<input type="hidden" name="business" value="chan_business@gmail.com">
							<input type="hidden" name="item_name" value="<?php echo $_SESSION['itemName'];?>">
							<input type="hidden" name="quantity" value="<?php echo $quant;?>">
							<!--<input type="hidden" name="item_price" value="<?php #echo $price;?>">-->
							<input type="hidden" name="amount" value="<?php echo $x;?>">
							<input type="hidden" name="return" value="http://localhost/onlineshopping/display_all_products.php">
							<input type="hidden" name="cancel_return" value="http://localhost/onlineshopping/display_all_products.php">
							


							
							 <!--<INPUT TYPE="hidden" NAME="currency_code" value="INR">-->

							

							
        
							
							
						<button type="submit" class="btn btn-primary">PAY NOW</button>
							
						</form>      
						
						
						
						<?php
						}
					}	
				?></a>
				
				
				
				
				
		</div>
	</div>
	
	
	
	
</div>


</div>
</div>

</body>	
<script>
	$(document).ready(function(){
		$('#paypalfrm').submit(function(e){
		
			$.ajax({
				type:"post",
				url:"mailTest1.php",
			data:{
				"email":'<?php echo $_SESSION['custEmail'];?>'
			},
			dataType:"json",
			success:function(data){
				console.log(data);
			},
			error:function(data){
				console.log(data);
			}
			});
			
			
			
	
					});
	});
</script>