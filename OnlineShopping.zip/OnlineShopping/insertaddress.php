<?php
	session_start();
	
	
?>
<?php
	$zipcode = $_POST['zipcode'];
	$address1=$_POST['address1'];
	$_SESSION['address1'] = $address1;
	if(isset($_POST['address2']))
	{
		$address2=$_POST['address2'];
		$_SESSION['address2']= $address2;
	}
	else
	{
		$address2="na";
	}
	if(isset($_POST['address3']))
	{
		
		$address3=$_POST['address3'];
		$_SESSION['address3'] = $address3;
	}
	else{
		$address3="na";
	}
	if(isset($_SESSION['Login']))
	{
		$login=$_SESSION['Login']; 
	}
	
	
	if(isset($_SESSION['quantity']))
	{
		$q=$_SESSION['quantity'];
	}
	else
	{
		$q="";
	}
	if(isset($_SESSION['productAmount']))
	{
		$pamt=$_SESSION['productAmount'];
	}
	else
	{
		$pamt="";
	}
	if(isset($_SESSION['productPrice']))
	{
		$p=$_SESSION['productPrice'];
	}
	else
	{
		$p="";
	}
	if(isset($_SESSION['ProductItemId']))
	{
		$pid=$_SESSION['ProductItemId'];
	}
	else
	{
		$pid="";
	}
	
	
	
	$purchaseDate = date('m/d/y');
	
	include('config.php');
	$ins="insert into address(zip_code_id,address1,address2,address3,user_id)values('".$zipcode."','".$address1."','".$address2."','".$address3."','".$login."')";
	$result=mysql_query($ins);
	if ($result){
	include('config.php');
	$insertOrder="insert into orders(user_id,item_id,quantity,amount,product_amount,purchase_date) values('".$login."','".$pid."','".$q."','".$p."','".$pamt."','".$purchaseDate."')";
	$exe = mysql_query($insertOrder);
	if($exe){
		header('Location:confirmation.php');
	}
	else{
		echo mysql_error();
	}
	
	}
	
	else
	{
		echo "problem inserting details".mysql_error();
	}
?>