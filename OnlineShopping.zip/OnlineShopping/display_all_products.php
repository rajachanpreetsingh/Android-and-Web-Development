<?php

include('refrence.php');
include('navigation.php');

?>

<body>

   

 <div class='container'>
    <div class='row'>
    <div class="col-lg-12">
    <div id="slider-carousel" class="carousel slide" data-ride="carousel" style="background-color:white;">
				<ol class="carousel-indicators">
					<li data-target="#slider-carousel" data-slide-to="0" class="active"></li>
					<li data-target="#slider-carousel" data-slide-to="1"></li>
					<li data-target="#slider-carousel" data-slide-to="2"></li>
				</ol>
				
				<div class="carousel-inner">
					<div class="item active">
						<div class="col-sm-5">
							<h1><span>E</span>-SHOPPER</h1>
							<h2> E-Commerce Shop online</h2>
							<p> Looking for Best Online shopping products in india with assured quality for men, women & kids for shoes, clothing, watches, ✓ free shipping* ✓ Cash on Delivery ✓ 15 days Return. <p>
						
							
						</div>
						<div class="col-sm-5">
							<img src="image/home/girl1.jpg" class="girl img-responsive" alt="" />
							
						</div>
					</div>
					
					
					<div class="item">
						<div class="col-sm-5">
							<h1><span>E</span>-SHOPPER</h1>
							<h2>E-commerce Responsive Design</h2>
							<p>Looking for Best Online shopping products in india with assured quality for men, women & kids for shoes, clothing, watches, ✓ free shipping* ✓ Cash on Delivery ✓ 15 days Return. </p>
							
						</div>
						<div class="col-sm-5">
							<img src="image/home/girl2.jpg" class="girl img-responsive" alt="" />
							
						</div>
					</div>
					
					<div class="item">
						<div class="col-sm-5">
							<h1><span>E</span>-SHOPPER</h1>
							<h2>E-commerce Responsive Design</h2>
							<p>Looking for Best Online shopping products in india with assured quality for men, women & kids for shoes, clothing, watches, ✓ free shipping* ✓ Cash on Delivery ✓ 15 days Return. </p>
							
						</div>
						<div class="col-sm-5">
							<img src="image/home/girl3.jpg" class="girl img-responsive" alt="" />
							
						</div>
					</div>
					
					<div class="item">
						<div class="col-sm-5">
							<h1><span>E</span>-SHOPPER</h1>
							<h2>E-commerce Responsive Design</h2>
							<p>Looking for Best Online shopping products in india with assured quality for men, women & kids for shoes, clothing, watches, ✓ free shipping* ✓ Cash on Delivery ✓ 15 days Return. </p>
							
						</div>
						<div class="col-sm-5">
							<img src="image/home/girl4.jpg" class="girl img-responsive" alt="" />
							
						</div>
					</div>
					
					
					<div class="item">
						<div class="col-sm-5">
							<h1><span>E</span>-SHOPPER</h1>
							<h2>E-commerce Website </h2>
							<p>Looking for Best Online shopping products in india with assured quality for men, women & kids for shoes, clothing, watches, ✓ free shipping* ✓ Cash on Delivery ✓ 15 days Return. </p>
							
						</div>
						<div class="col-sm-5">
							<img src="image/home/girl5.jpg" class="girl img-responsive" alt="" />
							
						</div>
					</div>
					
				</div>
				
				<a href="#slider-carousel" class="left control-carousel hidden-xs" data-slide="prev">
					<i class="fa fa-angle-left"></i>
				</a>
				<a href="#slider-carousel" class="right control-carousel hidden-xs" data-slide="next">
					<i class="fa fa-angle-right"></i>
				</a>
				
			</div>
    
    </div>
        <div class='col-lg-12' id='result'>
        <?php 
              	include('config.php');
              	
        		$show="SELECT * from product_items where is_active = 1";
             $res=mysql_query($show);
            if(mysql_num_rows($res)>0)
           {
          while($fetch=mysql_fetch_array($res)){
     ?> 
    <div class='col-sm-4'>
        <div class="thumbnail">
        <a class='productitemid' href="productpurchase.php?id=<?php echo $fetch['itemid'] ?>"> <img class="img-responsive productimage"
        src="uploadedfiles\<?php echo $fetch['image_url'];?>" alt="<?php echo $fetch['image_url'];?>" />
        </a>
        <div class='text-center productitemname' style="font-weight:bold;"><?php echo $fetch['item_name']; ?> </div>
        <div class='badge col-sm-offset-1 productprice'><?php echo $fetch['price']; ?> </div>
        <span class="col-md-offset-7"> <a class="productitemid btn btn-success" href="productpurchase.php?id=<?php echo $fetch['itemid'];?>">
        BUY</a></span>
       
        </div>
    </div>
    <?php
    
       }
    }
    
    ?>
        
        </div>
    </div>
 </div>
 
 
 
 
 
 
 
</body>