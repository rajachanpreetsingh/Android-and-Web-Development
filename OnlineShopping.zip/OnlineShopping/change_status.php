<?php 

if(isset($_POST["statusVal"]))
{
	if($_POST["statusVal"]==1){
	$pt=0;
	}
	else{
	$pt=1;
	}
	$id=$_POST['catId'];
	$sql='update person_category set is_active ="'.$pt.'" where id="'.$id.'"';
	

include('config.php');
	$mq = mysql_query($sql);
	if($mq)
	{
		echo json_encode($mq);
	}
	else
	{ 
		echo mysql_error();
	}
}
else{
echo json_encode('error');
}


?>