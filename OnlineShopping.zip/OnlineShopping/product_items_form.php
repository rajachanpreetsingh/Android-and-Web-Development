<?php 
include('refrence.php'); 

?>
<style>
.file{ 
	padding:8px;
}

</style>
<body>
<div class="container"> 
   <div class="row"> 
     <div class="col-lg-12">
     	<div class="well">
     		<h2 class="text-center">PRODUCT ITEM FORM </h2>
     	</div>
     </div>
     <div class="col-lg-12">
     	<form class="form-horizontal" method="post" action="insertproductitems.php" enctype="multipart/form-data">
  <div class="form-group">
    <label  class="col-sm-2 control-label">Product Category</label>
    <div class="col-sm-4">
      					
     	<select name="productcategory" class="form-control" required  >
     		<option value="">SELECT</option>
     <?php
     
     $sql="select * from person_product_category where is_active=1 ";
     
     include('config.php');
     $res=mysql_query($sql);
     if(mysql_num_rows($res)>0)
     {
     while($fetch=mysql_fetch_array($res)){
     ?> 
     <option value="<?php echo $fetch['subcategoryid'];?>"> <?php echo $fetch['product_name'] ;?></option>
     <?php
     }
     }
     ?>
     </select>
    </div>
  </div>
  
  <div class="form-group">
    <label  class="col-sm-2 control-label">Item Name</label>
    <div class="col-sm-4">
      <input type="text" class="form-control" name="itemname"  required>
    </div>
  </div>
 
    <div class="form-group">
    <label  class="col-sm-2 control-label">Price</label>
    <div class="col-sm-4">
      <input type="text" class="form-control" name="price"  required>
    </div>
  </div>
  
  <div class="form-group">
    <label  class="col-sm-2 control-label">Brand Name</label>
    <div class="col-sm-4">
      <input  class="form-control" type="text" class="form-control" name="brandname"  required>
    </div>
  </div>
  
    <div class="form-group">
    <label  class="col-sm-2 control-label">Type</label>
    <div class="col-sm-4">
      <input type="text" class="form-control" name="type"  required>
    </div>
  </div>
  
  
  
  <div class="form-group">
    <label  class="col-sm-2 control-label">Fabric</label>
    <div class="col-sm-4">
      <input type="text" class="form-control" name="fabric"  required>
    </div>
  </div>
  
  <div class="form-group">
    <label  class="col-sm-2 control-label">Colour</label>
    <div class="col-sm-4">
      <input type="text" class="form-control" name="colour"  required>
    </div>
  </div>
  
    
  
   <div class="form-group">
    <label class="col-sm-2 control-label" >Availability</label>
    <div class="col-sm-4 file">
        <input type="checkbox" name="availability"> Is Item Available
    </div>
  </div>
  
     <div class="form-group">
    <label class="col-sm-2 control-label" >Status</label>
    <div class="col-sm-4 file">
        <input type="checkbox" name="status"> Is_Active
    </div>
  </div>
  
   <div class="form-group">
    <label class="col-sm-2 control-label" > Upload Image </label> 
    <div class="col-sm-4 file">
      <input type="file"  required name="upload"/>
    </div>
  </div>
  <div class="form-group">
    <div class="col-sm-offset-2 col-sm-4">
     <button type="submit" name="create" class="btn btn-success">Submit</button>&nbsp;
  <button type="reset" class="btn btn-default">Reset</button>  
    </div>
  </div>
</form>	
     </div>
 </div>
</div>

</body>