<?php
	
	include('config.php');
	$prodCatId= $_POST['prodId'];
	$query="select * from product_items where category_ID='".$prodCatId."'";
	
	$result = mysql_query($query);
	
	if(mysql_num_rows($result) > 0){
		$prodarray = [];
		while($fetch = mysql_fetch_array($result))
		{
			array_push($prodarray, [
			//'prodId' => $fetch['prodId'],
			'imageURL' => $fetch['image_URL'],
			'Price'  => $fetch['price'],
			'itemName' => $fetch['item_Name'],
			'itemID' => $fetch['item_ID']
			]);
			}
		$arrayJSON = json_encode($prodarray);
		echo $arrayJSON;
		}
	else{
		echo 'false';
	}
?>