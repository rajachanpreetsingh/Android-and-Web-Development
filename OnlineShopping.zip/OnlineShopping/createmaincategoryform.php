 <?php 
include('refrence.php');
?>
<?php

if(isset($_POST['update'])){
$name = ucwords(trim($_POST['categoryname']));
if(isset($_POST['status'])){
$status = true;
}
else{
$status = false;
}

$upSql = 'update person_category set category_name="'.$name.'",is_active="'.$status.'" where id='.$_GET['edit_id'];


include('config.php');
$resupd = mysql_query($upSql);
if($resupd){
header('Location:allmaincategories.php');
}
else{
echo mysql_error();
}
}
?>
<?php
if (isset($_GET['edit_id'])){
$sel="select * from person_category where id=".$_GET['edit_id'];
include('config.php');
$msr=mysql_query($sel);
$ms = mysql_fetch_array($msr);

}
include('refrence.php'); 
?>

<body>
<div class="container"> 
   <div class="row"> 
     <div class="col-lg-12">
     	<div class="well">
     		<h2 class="text-center">Create Person Category</h2>
     	</div>
     </div>
          <div class="col-lg-12"> 
            <?php
          if(isset($_GET['edit_id'])){
          	 $action = '';
          }
          else{
          	$action = 'action="insertmaincategory.php"';	
          }
          
          ?>
        
               <form class="form-inline" method="post" <?php echo $action;?>>
               <div class="col-md-12">
               		<div class="col-md-4">
               			<div class="form-group">
    						<label>Person Category Name</label>
    						<?php
    							if(isset($ms['category_name'])){
    								$catname=$ms['category_name'];
    							}
    							else{
    								$catname='';
    							}
    						?>
    						<input type="text" class="form-control" name="categoryname" value="<?php echo $catname;?>">
 						 </div>
    						
  					</div>
               		<div class="col-md-1"></div>
               		<div class="col-md-4">
               		 <div class="form-group">
               			<div class="col-md-6">
               				<label for="isactive">Status</label>
               			</div>
    					
    					<?php
    	  					if(isset($ms['is_active']) && $ms['is_active']==1){
    							$check = 'checked';
    						}
    						else{
    							$check='';
    						}
    					?>
   					 <input type="checkbox" name="status" <?php if(isset($check)) echo $check;?>> Is Active
  					</div> 
  
    					
  					</div> 
               		<div class="col-md-3">
               			<div class="form-group">
               				<?php
  								if(isset($_GET['edit_id'])){
									echo '<button type="submit" name="update" class="btn btn-warning">Update</button>&nbsp;<a href="allmaincategories.php" class="btn btn-danger" >CANCEL</a>';
									
  								}
  								else{
  									echo '<button type="submit" name="createcategory" class="btn btn-success">Submit</button>&nbsp;<button type="reset" class="btn btn-default">Reset</button>';
  								}
  							?>
               			</div>
               		</div>
               		</div>
               		
               </div>
  
  
  
  
</form>
          </div>
     </div>
</div>

</body>