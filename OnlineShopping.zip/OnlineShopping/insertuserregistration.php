<?php
	session_start();
	include("config.php");
	$firstName=$lastName=$mobile=$email=$gender=$password="";
	$firstName=$_POST['firstName'];
	$lastName=$_POST['lastName'];
	$mobile=$_POST['mobile'];
	$email=$_POST['Email'];
	$gender=$_POST['gender'];
	$password=$_POST['password'];
	$active = 1;
	$role = 2;
	
	$ins="insert into user_register(first_name,last_name,mobile,email,gender,password, is_active, user_role_id)Values('".$firstName."', '".$lastName."','".$mobile."', '".$email."','".$gender."','".$password."',	'".$active."','".$role."')";
	
	$result=mysql_query($ins);
	$lastInsId = mysql_insert_id();
	$_SESSION['Login'] = $lastInsId;
	if($result)
	{
		header('Location:shipping.php');	
		
	}
	else{
		echo "problem inserting data". mysql_error();
	}
	
?>