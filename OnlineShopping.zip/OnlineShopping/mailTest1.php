<?php
	
 	
$rMail = $_POST['email'];

SendMail($rMail); //function called to send email

function SendMail($recepientEmail)
{

require 'PHPMailerAutoload.php';

$mail = new PHPMailer;

//$mail->SMTPDebug = 3;                               // Enable verbose debug output

$mail->isSMTP();                                      // Set mailer to use SMTP
$mail->Host = 'smtp.gmail.com;smtp.gmail.com';  // Specify main and backup SMTP servers
$mail->SMTPAuth = true;                               // Enable SMTP authentication
$mail->Username = 'rajachanpreetsingh@gmail.com';                 // SMTP username   here you will pass the valid email. You can pass your email
$mail->Password = '959295555900raja';                // SMTP password    here you will pass the password of your email. You can pass your password
$mail->SMTPSecure = 'tls';                            // Enable TLS encryption, `ssl` also accepted
$mail->Port = 587;                                    // TCP port to connect to

$mail->From = 'rajachanpreetsingh@gmail.com';                     // here you will pass the email of sender. You can pass your own
$mail->FromName = 'admin';            // here you can pass your name
$mail->addAddress($recepientEmail);     // Add a recipient. here you will pass the variable from function and second parameter as name which is optional
               

$mail->Subject = 'Order Placed'; //this is the subject of the message
$mail->Body    = 'You Order has been placed and will reach you in 2-3 days.';   //this is the body of message. you will write it in a string
$issent = $mail->send();
if($issent){
	echo true;
}
else{
	echo $mail->ErrorInfo;
}
//if(!$mail->send()) {
//    echo 'Message could not be sent.';
//    echo 'Mailer Error: ' . $mail->ErrorInfo;
//} else {
//    echo 'Message has been sent';
//}
}
?>