<?php

if(isset($_POST['create'])){
$productcatid=$_POST['productcategory'];

$name = ucfirst(trim($_POST['itemname']));
if(isset($_POST['status'])){
$status = true;
}
else{
$status = false;
}
if(isset($_POST['availability'])){
$avalability = true;
}
else{
$avalability = false;
}


$c=trim($_POST['price']);
$d=trim($_POST['type']);
$e=trim($_POST['brandname']);
$f=date("Y/m/d");
$h=trim($_POST['colour']);
$i=trim($_POST['fabric']);


if(isset($_FILES['upload'])){
	$file = $_FILES['upload'];
	$n = $file['name'];
	$s = $file['size'];
	$tm = $file['tmp_name'];
	$er = $file['error'];
	$target = 'uploadedfiles/'.$n;
	
	if(move_uploaded_file($tm, $target)){
		$sql = "insert into product_items(item_name, is_active, category_id, image_url, date_created, is_item_available, type, brand_name, fabric, colour,price) ";
        $sql .= " values('".$name."','".$status."','".$productcatid."','".$n."','".$f."','".$avalability."','".$d."','".$e."','".$i."','".$h."','".$c."')";
        include('config.php');
        $res = mysql_query($sql);
        if($res){
        $l_id = mysql_insert_id();
          header('Location:size_quantity_form.php?item_id='.$l_id);
          echo 'success';
        }
        else{
          echo mysql_error();
        }
	}
	else{
		echo 'error uploading file. '.$er;
	}
}


}
else{
	echo 'error';
}
?>