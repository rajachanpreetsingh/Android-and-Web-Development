<?php
	include('refrence.php');
	include('navigation.php');
?>


<style>
	body{
	background:url('images/');
	}
</style>

<div class="container">
	<div class="row">
		<div class="col-lg-12" style="padding-left:20px;">
			<div id="slider-carousel" class="carousel slide" data-ride="carousel" style="background-color:white;">
				<ol class="carousel-indicators">
					<li data-target="#slider-carousel" data-slide-to="0" class="active"></li>
					<li data-target="#slider-carousel" data-slide-to="1"></li>
					<li data-target="#slider-carousel" data-slide-to="2"></li>
				</ol>
				
				<div class="carousel-inner">
					<div class="item active">
						<div class="col-sm-5">
							<h1><span>E</span>-SHOPPER</h1>
							<h2> E-Commerce Shop online</h2>
							<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. </p>
							
						</div>
						<div class="col-sm-5">
							<img src="images/home/girl1.jpg" class="girl img-responsive" alt="" />
							
						</div>
					</div>
					<div class="item">
						<div class="col-sm-6">
							<h1><span>E</span>-SHOPPER</h1>
							<h2>E-commerce Responsive Design</h2>
							<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. </p>
							
						</div>
						<div class="col-sm-6">
							<img src="images/home/girl2.jpg" class="girl img-responsive" alt="" />
							
						</div>
					</div>
					
					<div class="item">
						<div class="col-sm-6">
							<h1><span>E</span>-SHOPPER</h1>
							<h2>E-commerce Website </h2>
							<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. </p>
							
						</div>
						<div class="col-sm-6">
							<img src="images/home/girl3.jpg" class="girl img-responsive" alt="" />
							
						</div>
					</div>
					
				</div>
				
				<a href="#slider-carousel" class="left control-carousel hidden-xs" data-slide="prev">
					<i class="fa fa-angle-left"></i>
				</a>
				<a href="#slider-carousel" class="right control-carousel hidden-xs" data-slide="next">
					<i class="fa fa-angle-right"></i>
				</a>
				
			</div><br>
		</div>	
		
		<div class="col-md-12" id="result">
			
			<?php
				include('config.php');
				
				
				$query = "select itemID,imageURL,itemName,price from productitems limit 9";
				
				$result = mysql_query($query);	
				
				if(mysql_num_rows($result) > 0)
				{
					
					while($fetch = mysql_fetch_array($result))
					{
					?>
					
					
					<div class="col-sm-4">
						<div class="thumbnail">
							
							<a class="productitemid" href="productpurchase.php?id=<?php echo $fetch['itemID'];?>"><img class="img-responsive productimage" src="uploadedfiles\<?php echo $fetch['imageURL'];?>" alt="<?php echo $fetch['imageURL'];?>" /></a>
							
							<div class="text-center productitemname" style="font-weight:bold;"><?php echo $fetch['itemName']; ?></div>
							<div class="badge col-sm-offset-1 productprice"><?php echo $fetch['price']; ?></div>
							<span class="col-md-offset-7"><a class="productitemid btn btn-success" href="productpurchase.php?id=<?php echo $fetch['itemID'];?>">BUY</a></span>
							
						</div>
					</div>
					<?php
					}
					
				}	
			?>
		</div>
	</div>
</div>
<script>
	$(document).ajaxStart(function () {
		
        NProgress.start();
        
		
		}).ajaxStop(function () {
        
        NProgress.done();
        
	});
</script>

<script>
	$(document).ready(function () {
	 var pageCount = 0;
  document.addEventListener('scroll', function (event) {
           
	if (document.body.scrollHeight==
				(document.body.scrollTop + window.innerHeight) ||document.body.scrollHeight ==($("html").scrollTop()+window.innerHeight)) {
		
			LoadMore();

}

}, false);

function LoadMore(){
	
	$.ajax({
		
		type:"post",
		url:"getMoreItems.php",
		data:{
			"PageCount" : pageCount
		},
		dataType:"json",
		success: function(data){
		pageCount++;
		$.each(data, function(){
			var itemId = this.ItemId;
			var imageUrl = this.ImageUrl;
			var itemName = this.ItemName;
			var price = this.Price;
			
			var x = '<div class="col-sm-4"><div class="thumbnail"><a class="productitemid" href="productpurchase.php?id='+itemId+'"><img class="img-responsive productimage" src="uploadedfiles\/'+imageUrl+'" alt="'+imageUrl+'" /></a><div class="text-center productitemname" style="font-weight:bold;">'+itemName+'</div><div class="badge col-sm-offset-1 productprice">'+price+'</div><span class="col-md-offset-7"><a class="productitemid btn btn-success" href="productpurchase.php?id='+itemId+'" class="btn btn-success" >BUY</a></span></div></div>';
			$("#result").append(x);
		});
		},
		error: function(data){
			console.log(data);
		}
	
	});
}
	});
</script>
</body>
