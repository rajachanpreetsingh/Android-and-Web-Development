<?php

if(isset($_POST['create'])){
$itemid=$_POST['productcategory'];	
$a=trim($_POST['availablequantity']);
$s=$_POST['size'];
foreach($s as $item){
$sql = "insert into size_quantity(itemid,size,availablequantity) ";
 $sql .= " values('".$itemid."','".$item."','".$a."')";
 include('config.php');
 $res = mysql_query($sql);
 }
 if($res){
 
   header('Location:product_items_form.php');
         }
        else{
          echo mysql_error();
        }
	
}
else {
		echo 'error';
	}

?>